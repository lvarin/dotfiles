require("config.lazy")
